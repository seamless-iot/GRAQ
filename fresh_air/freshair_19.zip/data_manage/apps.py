from django.apps import AppConfig


class DataVisualizeConfig(AppConfig):
    name = 'data_visualize'
