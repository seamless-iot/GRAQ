from django.apps import AppConfig


class DataPushConfig(AppConfig):
    name = 'data_push'
