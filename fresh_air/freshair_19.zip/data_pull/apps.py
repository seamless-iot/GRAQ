from django.apps import AppConfig


class DataPullConfig(AppConfig):
    name = 'data_pull'
