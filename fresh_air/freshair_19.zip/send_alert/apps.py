from django.apps import AppConfig


class SendAlertConfig(AppConfig):
    name = 'send_alert'
